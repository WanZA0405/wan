# MyBatis-Spring 结合1

导入依赖

```xml
<!-- MyBatis-Spring -->
		<dependency>
			<groupId>org.mybatis</groupId>
			<artifactId>mybatis-spring</artifactId>
			<version>1.3.3</version>
		</dependency>
		<!-- spring-jdbc -->
		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-jdbc</artifactId>
			<version>5.2.9.RELEASE</version>
		</dependency>
```

**必须与Spring的版本对应**

- Mybatis：Mybatis框架是通过解析xml，通过SqlSessionFactoryBuilder的build方法创建出SqlSessionFactory对象，在通过openSession方法获取sqlSession对象，在通过getMapper方法动态获取映射接口的实现类对象，执行映射文件中的sql语句，完成与数据库的交互
- Spring和Mybatis结合：需要导入相关jar包mybatis-spring-1.2.2.jar，Spring中通过SqlSessionFactoryBean创建出sqlSessionFactory对象注入到Bean容器中（有两种方式执行sql语句）
  1. 可以从Bean容器中获取sqlSessionFactory对象，获取sqlSession对象，动态获取接口实现类对象，执行sql
  2. Spring帮我们动态代理创建接口实现类对象，执行sql语句
- 可以单独配置Mybatis-config.xml，也可以将Mybatis-config.xml整合到Spring配置文件中
- Spring配置文件引入mybatis-config.xml文件
