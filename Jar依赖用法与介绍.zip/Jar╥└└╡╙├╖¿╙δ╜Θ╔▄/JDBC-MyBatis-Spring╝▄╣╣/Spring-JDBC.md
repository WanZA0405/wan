# Spring-JDBC结合

导入依赖

```xml
<!-- MyBatis-Spring -->
		<dependency>
			<groupId>org.mybatis</groupId>
			<artifactId>mybatis-spring</artifactId>
			<version>1.3.3</version>
		</dependency>
		<!-- spring-jdbc -->
		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-jdbc</artifactId>
			<version>5.2.9.RELEASE</version>
		</dependency>
```

**必须与Spring的版本对应**

- Spring提供了org.springframework.jdbc.core.JdbcTemplate：这是Spring中JDBC核心包的类，用来简化JDBC使用
- JdbcTemplate类中存在执行SQL语句对应方法（增，删，改，查）
- Jdbc的操作语言的事物默认是自动提交的。

