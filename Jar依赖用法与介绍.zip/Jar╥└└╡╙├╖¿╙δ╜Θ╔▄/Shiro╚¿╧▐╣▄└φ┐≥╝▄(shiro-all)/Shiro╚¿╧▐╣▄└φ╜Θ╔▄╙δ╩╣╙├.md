# Shiro权限控制框架



## 专业术语

Security			安全			 			

subject			 主题	

realm				领域	   	

Filter				  过滤器

Proxy				代理

Delegating		授权、委派	  		



anonymous			 anon    匿名

authentication		authc   认证

Authorization         			 授权







## 1.shiro基本概念



Apache Shiro是一个强大且易用的Java安全框架,执行身份认证、授权、密码和会话管理。使用Shiro的易于理解的API,您可以快速、轻松地获得任何应用程序,从最小的移动应用程序到最大的网络和企业应用程序。



```tex
三个核心组件

		Subject					相当于用户 

		SecurityManager 		安全管理器

		Realm					认证通过的领域

Subject：即“当前操作用户”。但是，在Shiro中，Subject这一概念并不仅仅指人，也可以是第三方进程、后台帐户或其他类似事物。它仅仅意味着“当前跟软件交互的东西”。
SecurityManager：它是Shiro框架的核心，shiro通过SecurityManager来管理内部组件实例，并通过它来提供安全管理的各种服务。
Realm： Realm充当了Shiro与应用安全数据间的“桥梁”或者“连接器”。也就是说，当对用户执行认证（登录）和授权（访问控制）验证时，Shiro会从应用配置的Realm中查找用户及其权限信息。


```



运行流程      

​			应用程序->Subject->SecurityManager->Realm->安全数据 





认证和授权区别

​		  认证就是判断当前登录用户是否正常。

​          授权就是判断用户是否有权限访问功能。

​          首先先要认证登录，然后才能授权



 



## 2.shiro初步环境搭建



实现访问后台管理页面，统一跳转至登录页面



步骤1，添加依赖

```xml
<dependency>
 <groupId>org.apache.shiro</groupId>
 <artifactId>shiro-all</artifactId>
 <version>1.5.1</version>
</dependency>
```

步骤2，配置过滤器

```xml
<filter>
   <filter-name>shiroFilter</filter-name>
   <filter-class>org.springframework.web.filter.DelegatingFilterProxy</filter-class>
</filter>
<filter-mapping>
   <filter-name>shiroFilter</filter-name>
   <url-pattern>/*</url-pattern>
</filter-mapping>
```

步骤3，shiro过滤工厂配置

```xml
<bean id="shiroFilter" class="org.apache.shiro.spring.web.ShiroFilterFactoryBean">
   <!--安全管理器-->
   <property name="securityManager" ref="securityManager"></property>
   <!--登录页-->
   <property name="loginUrl" value="/login.html"></property>
   <!-- url过滤器控制规则-->
   <property name="filterChainDefinitions">
      <value>
         /login.html*=anon
	      /user/login*=anon
         /js/**=anon
         /css/**=anon
         /img/**=anon
        
         
         /**=authc
      </value>
   </property>
</bean>

     <!--配置安全管理器-->
    <bean id="securityManager" class="org.apache.shiro.web.mgt.DefaultWebSecurityManager">
        <property name="realm" ref="myRealm" ></property>
    </bean>

    <bean id="myRealm" class="com.tykh.controller.MyRealm"></bean>

    <!--Shiro生命周期处理器-->
    <bean id="lifecycleBeanPostProcessor"
          class="org.apache.shiro.spring.LifecycleBeanPostProcessor">
    </bean>
```



## 3.shiro用户登录认证

登录Controller方法

```
@Controller
@RequestMapping("/user")
public class LoginController  {

   @RequestMapping("/login")
   public String login(Employee emp){
      Subject subject = SecurityUtils.getSubject();
   
      AuthenticationToken token = new UsernamePasswordToken(emp.getUsername(), emp.getPassword());
      try {
         subject.login(token);
         return "redirect:/admin/index.html";
      } catch (AuthenticationException e) {
         e.printStackTrace();
         return "redirect:/login.html";
      }
   }
}
```



实现MyRealm用户认证

```java
@Controller("myRealm")
public class MyRealm extends AuthorizingRealm {
    @Autowired
    EmployeeService employeeService;
    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        UsernamePasswordToken up = (UsernamePasswordToken) token;
        Employee emp = employeeService.getByUserNmae(up.getUsername());
        if(emp==null){
            //找不到
            return null;
        }else{
            //找到了验证密码
            return new SimpleAuthenticationInfo(emp, emp.getPassword(),  getName());
        }
    }
}
```



注销方法

```java
@RequestMapping("/logout")
public String logout(){
   Subject subject = SecurityUtils.getSubject();

   subject.logout();
   return "redirect:/login.html";
}
```



## 4.课后作业

使用ssm整合架构下，

1.完成用户和角色模块的增删改查功能

2.用户列表中显示角色，以及新增用户时可以选角色

用户表(Employees)

| 字段名称 | 数据类型    | 是否为空 | 说明               |
| -------- | ----------- | -------- | ------------------ |
| empid    | Int         | 否       | 用户id,主键,标识列 |
| username | Varchar(10) | 否       | 用户登录名         |
| password | Varchar(6)  | 否       | 密码               |
| tel      | Varchar(30) | 否       | 联系电话           |
| name     | Varchar(20) | 否       | 用户姓名           |
| email    | Varchar(50) |          | 邮箱               |
| roleid   | int         | 否       | 角色类型           |

角色表(role)

| 字段名称 | 数据类型     | 是否为空 | 说明           |
| -------- | ------------ | -------- | -------------- |
| roleid   | Int          | 否       | id,主键,标识列 |
| roleName | Varchar(50)  | 否       | 名称           |
| roleInfo | Varchar(100) | 否       | 描述           |

