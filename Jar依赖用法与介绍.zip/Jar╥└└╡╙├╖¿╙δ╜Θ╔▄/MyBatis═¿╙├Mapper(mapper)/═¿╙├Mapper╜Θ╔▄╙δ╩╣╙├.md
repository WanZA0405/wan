# 通用Mapper介绍

## 导入依赖

```xml
<!-- mybatis通用mapper -->
		<dependency>
			<groupId>tk.mybatis</groupId>
			<artifactId>mapper</artifactId>
			<version>4.1.5</version>
		</dependency>
```

**不会影响之前没有继承通用Mapper的Mapper接口**

### 但是只适合单表,方法不够可以扩展

## 使用

**Springframework  spring-context配置文件中修改mapper加载实体类**

```xml
<!-- 加载Mapper类的实现类 -->
	<bean class="tk.mybatis.spring.mapper.MapperScannerConfigurer">
		<property name="sqlSessionFactoryBeanName"
			value="sqlSessionFactory" />
		<!-- 扫描com.shop.mapper 下的接口新建实现类 -->
		<property name="basePackage" value="com.tykh.mapper" />
	</bean>
```

**之后Mapper接口继承Mapper<对象实体类>接口**

```java
extends Mapper<E>
```



## 实例

```java
@Override
	@Transactional
	public Dept getById(Integer deptId) {
		return deptMapper.selectByPrimaryKey(deptId);
	}

	@Override
	@Transactional
	public Dept getByName(String deptName) {
		Example example = new Example(Dept.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("deptName",deptName);
		return deptMapper.selectOneByExample(example);
	}

```

可搭配mybatis分页插件一起使用（pagehelper）

导入依赖

```xml
<!-- mybatis分页插件 -->
		<dependency>
			<groupId>com.github.pagehelper</groupId>
			<artifactId>pagehelper</artifactId>
			<version>5.1.8</version>
		</dependency>
```

