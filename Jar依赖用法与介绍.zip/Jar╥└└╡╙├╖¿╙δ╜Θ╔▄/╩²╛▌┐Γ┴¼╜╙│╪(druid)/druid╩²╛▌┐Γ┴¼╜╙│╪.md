# druid数据库链接池

依赖于JDBC jar包 必须有数据库架包 

```xml
<dependency>
			<groupId>mysql</groupId>
			<artifactId>mysql-connector-java</artifactId>
			<version>5.1.49</version>
		</dependency>
```

加载依赖

```xml
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
    <version>1.1.22</version>
</dependency>
```

用于创建多个链接到数据库的库存/工厂,每个sqlsession相当于数据库链接connection

```java
private static DruidDataSource dataSource = null;
	static {
		Properties properties = new Properties();
		try {
			dataSource = new DruidDataSource();
			//类加载器
			properties.load(DbUtile.class.getClassLoader().getResourceAsStream("jdbc.properties"));
			dataSource.setDriverClassName(properties.getProperty("driver"));
			dataSource.setUrl(properties.getProperty("url"));
			dataSource.setUsername(properties.getProperty("name"));
			dataSource.setPassword(properties.getProperty("pwd"));
            //最多链接数-8
			dataSource.setMaxActive(8);
            //最多等待时间
			dataSource.setMaxWait(5000);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 建立链接
	 * 
	 * @throws SQLException
	 */
	public static Connection initConn() throws SQLException{
	   Connection	conn = dataSource.getConnection();
	   return conn;
	}

	/**
	 * 关闭链接
	 * @param conn 当前使用的链接
	 * 
	 */
	public static void closeConn(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//测试数据库
	public static void main(String[] args) {
		try {
			Connection connection= DbUtile.initConn();
			System.out.println(connection);
			DbUtile.closeConn(connection);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
```

