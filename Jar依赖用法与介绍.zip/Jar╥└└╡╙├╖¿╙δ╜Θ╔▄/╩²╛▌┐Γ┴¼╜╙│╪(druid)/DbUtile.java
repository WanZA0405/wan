package com.utiles;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;


import com.alibaba.druid.pool.DruidDataSource;

public class DbUtile {

	private static DruidDataSource dataSource = null;
	static {
		Properties properties = new Properties();
		try {
			dataSource = new DruidDataSource();
			//�������
			properties.load(DbUtile.class.getClassLoader().getResourceAsStream("jdbc.properties"));
			dataSource.setDriverClassName(properties.getProperty("driver"));
			dataSource.setUrl(properties.getProperty("url"));
			dataSource.setUsername(properties.getProperty("name"));
			dataSource.setPassword(properties.getProperty("pwd"));
			dataSource.setMaxActive(8);
			dataSource.setMaxWait(5000);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * ��������
	 * 
	 * @throws SQLException
	 */
	public static Connection initConn() throws SQLException{
	   Connection	conn = dataSource.getConnection();
	   return conn;
	}

	/**
	 * �ر�����
	 * @param conn ��ǰʹ�õ�����
	 * 
	 */
	public static void closeConn(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//�������ݿ�
	public static void main(String[] args) {
		try {
			Connection connection= DbUtile.initConn();
			System.out.println(connection);
			DbUtile.closeConn(connection);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
