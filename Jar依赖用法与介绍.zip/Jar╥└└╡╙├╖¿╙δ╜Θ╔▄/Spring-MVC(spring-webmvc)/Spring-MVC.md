# Spring-MVC

## 导入依赖

```xml
<!-- Spring and Spring MVC -->
		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-webmvc</artifactId>
			<version>5.2.9.RELEASE</version>
		</dependency>
```

自带Springframework