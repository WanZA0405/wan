# POI

 POI 是用java编写的免费开源的跨平台的 Java API，Apache POI提供API给Java程式对[Microsoft Office](https://baike.baidu.com/item/Microsoft Office)格式档案读和写的功能。

POI为“Poor Obfuscation Implementation”的首字母缩写，意为简洁版的模糊实现

Apache POI是基于Office Open XML标准（OOXML）和Microsoft的OLE 2复合文档格式（OLE2）处理各种文件格式的开源项目。 简而言之，您可以使用Java读写MS Excel文件.



# 导入依赖

```
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi</artifactId>
    <version>4.1.1</version>
</dependency>

<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-ooxml</artifactId>
    <version>4.1.1</version>
</dependency>
```



```
//创建excel工作簿
HSSFWorkbook excel = new HSSFWorkbook();
//创建sheet对象
HSSFSheet sheet = excel.createSheet();//"第一个sheet"
//创建行对象
HSSFRow row = sheet.createRow(0);
//创建列对象
HSSFCell c0 = row.createCell(0);
HSSFCell c1 = row.createCell(1);

//写数据
c0.setCellValue("1001");
c1.setCellValue("沈腾");

//工作簿导出成excel  写出
FileOutputStream fos = new FileOutputStream("d:/first.xls");
excel.write(fos);
//关闭资源
fos.close();

System.out.println("操作完成");
```



## 2.POI操作Excel导出

```
private static void exportData() throws IOException {
    List<Emp> emps = Arrays.asList(new Emp(1001, "高圆圆"),
            new Emp(1002, "刘诗诗")
    );

    HSSFWorkbook excel =new HSSFWorkbook();
    HSSFSheet sheet = excel.createSheet("统计员工");
    String titles[] = {"编号","姓名"};
    HSSFRow rowTitle = sheet.createRow(0);
    
    for (int i = 0; i < titles.length; i++) {
        rowTitle.createCell(i).setCellValue(titles[i]);
    }

    for (int i = 0; i < emps.size(); i++) {
        HSSFRow row = sheet.createRow(i + 1);
        row.createCell(0).setCellValue(emps.get(i).getEmpno());
        row.createCell(1).setCellValue(emps.get(i).getEname());
    }

    //保存输出
    FileOutputStream fos = new FileOutputStream("d:/emps.xls");
    excel.write(fos);
    fos.close();

    System.out.println("操作完成");
}
```

## 3.POI操作Excel导入

```
private static void importData() throws Exception {
    FileInputStream fis = new FileInputStream("d:/emps.xls");
    Workbook excel = WorkbookFactory.create(fis);
    Sheet sheet = excel.getSheetAt(0);

    List<Emp> emps = new ArrayList<>();
    for (int i = 1; i <=sheet.getLastRowNum(); i++) {
        Row row = sheet.getRow(i);
        Emp emp = new Emp();
        emp.setEmpno((int)(row.getCell(0).getNumericCellValue()));
        emp.setEname(row.getCell(1).getStringCellValue());
        emps.add(emp);
    }

    System.out.println(emps);
    //关闭
    fis.close();


}
```



## 4.POI操作Excel导出Web版

```
<a href="exportData">下载</a>
```

```
@RequestMapping("/exportData")
public String exportData(HttpServletResponse response) throws IOException {
    List<Emp> emps = Arrays.asList(new Emp(1001, "高圆圆3"),
            new Emp(1002, "刘诗诗3")
    );

    HSSFWorkbook excel =new HSSFWorkbook();
    HSSFSheet sheet = excel.createSheet("统计员工");
    String titles[] = {"编号","姓名"};
    HSSFRow rowTitle = sheet.createRow(0);
    for (int i = 0; i < titles.length; i++) {
        rowTitle.createCell(i).setCellValue(titles[i]);
    }

    for (int i = 0; i < emps.size(); i++) {
        HSSFRow row = sheet.createRow(i + 1);
        row.createCell(0).setCellValue(emps.get(i).getEmpno());
        row.createCell(1).setCellValue(emps.get(i).getEname());
    }

    // 生成文件名
    String filename = UUID.randomUUID().toString() + ".xls";
    System.out.println("filename = " + filename);

    try {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-Disposition", "attachment; filename=" + filename);
        excel.write(response.getOutputStream());
        response.getOutputStream().flush();
    } catch (Exception e) {
    }finally{
        if(excel!=null){
            excel.close();
        }
        if(response.getOutputStream()!=null){
            response.getOutputStream().close();
        }
    }

    System.out.println("下载操作完成");
    return  "success";

}
```



## 5.POI操作Excel导入Web版

文件上传

```
<dependency>
    <groupId>commons-fileupload</groupId>
    <artifactId>commons-fileupload</artifactId>
    <version>1.4</version>
</dependency>
```

```

<form  action="importData" method="post"
      enctype="multipart/form-data">
    <input type="file" name="file">
    <input type="submit" name="" value="上传">
</form>
```

配置

```
<!--文件上传解析器-->
<bean id="multipartResolver" class="org.springframework.web.multipart.commons.CommonsMultipartResolver">
   <property name="defaultEncoding" value="utf-8"></property>
   <!--文件大小限制 单位字节-->
   <property name="maxUploadSize" value="10240000"></property>
</bean>
```



```
@RequestMapping("/importData")
public String importData(MultipartFile file) throws IOException {
    InputStream in = file.getInputStream();
    Workbook excel = WorkbookFactory.create(in);
    Sheet sheet = excel.getSheetAt(0);

    List<Emp> emps = new ArrayList<>();
    for (int i = 1; i <=sheet.getLastRowNum(); i++) {
        Row row = sheet.getRow(i);
        Emp emp = new Emp();
        emp.setEmpno((int)(row.getCell(0).getNumericCellValue()));
        emp.setEname(row.getCell(1).getStringCellValue());
        emps.add(emp);
    }

    System.out.println(emps);
    //关闭
    in.close();

    return "success";
}
```

