package com.lib.test;

import com.lib.model.Role;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PoiTest {

    @Test
    public void OutStreamExport() {
        //新建工作表格
        HSSFWorkbook excel = new HSSFWorkbook();
        //新建表格1
        HSSFSheet sheet = excel.createSheet("表1");
        //表格1 第一行
        HSSFRow row = sheet.createRow(0);
        //第一行 第一列 单元格对象
        HSSFCell c0 = row.createCell(0);
        HSSFCell c1 = row.createCell(1);
        HSSFCell c2 = row.createCell(2);
        c0.setCellValue(1);
        c1.setCellValue("管理员");
        c2.setCellValue("负责后台全部数据的管理");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("d:/表1.xlsx");
            excel.write(fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        System.out.println("操作完成");
    }

    @Test
    public void outputStreamExport2() {
        List<Role> roles = new ArrayList<>();
        roles.add(new Role(1, "管理员", "负责后台全部数据的管理"));
        roles.add(new Role(2, "图书管理员", "负责管理图书与预借"));
        roles.add(new Role(3, "读者", "可以借阅图书"));
        //新建工作表格
        HSSFWorkbook excel = new HSSFWorkbook();
        //新建角色表
        HSSFSheet sheet = excel.createSheet("角色表");
        //新建 角色表 表头
        HSSFRow headerRow = sheet.createRow(0);
        //第一行 第一列 单元格对象
        HSSFCell c0 = headerRow.createCell(0);
        HSSFCell c1 = headerRow.createCell(1);
        HSSFCell c2 = headerRow.createCell(2);
        c0.setCellValue("角色编号");
        c1.setCellValue("角色名称");
        c2.setCellValue("角色详情");
        for (int i = 0; i < roles.size(); i++) {
            HSSFRow Row = sheet.createRow(i + 1);
            Role role = roles.get(i);
            c0 = Row.createCell(0);
            c1 = Row.createCell(1);
            c2 = Row.createCell(2);
            c0.setCellValue(role.getRoleid());
            c1.setCellValue(role.getRolename());
            c2.setCellValue(role.getRoleinfo());
        }
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("d:/表1.xlsx");
            excel.write(fos);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        System.out.println("操作完成");

    }

    @Test
    public void inputStreamImport() {
        FileInputStream fis = null;
        List<Role> roles = new ArrayList<>();
        try {
            fis = new FileInputStream("d:/表1.xlsx");
            Workbook excel = WorkbookFactory.create(fis);
            Sheet sheet = excel.getSheet("角色表");
            int lastRowNum = sheet.getLastRowNum();
            for (int i = 1; i <= lastRowNum; i++) {
                Role role = new Role();
                Row row = sheet.getRow(i);
                role.setRoleid((int) row.getCell(0).getNumericCellValue());
                role.setRolename(row.getCell(1).getStringCellValue());
                role.setRoleinfo(row.getCell(2).getStringCellValue());
                roles.add(role);
            }
            for (Role role : roles) {
                System.out.println(role);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
