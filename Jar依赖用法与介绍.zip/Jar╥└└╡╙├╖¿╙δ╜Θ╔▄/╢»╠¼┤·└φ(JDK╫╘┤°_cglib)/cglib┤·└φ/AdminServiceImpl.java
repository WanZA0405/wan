package com.tykh.test;

public class AdminServiceImpl implements AdminService{

	@Override
	public String show(String msg) {
		return msg;
	}
	
	public String getMessage(String msg) {
		return msg;
	}
}
