package com.tykh.test;

public interface AdminService {
	String show(String msg);
}
