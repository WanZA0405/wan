# Jstl——JSP页面脚本插入

## JSTL概述

​     **JSTL（JSP Standard Tag Library)**，JSP标准标签库，可以嵌入在jsp页面中使用标签的形式完成业务逻辑等功能。jstl出现的目的同el一样也是要代替jsp页面中的脚本代码。JSTL标准标签库有5个子库，但随着发展，目前常使用的是他的核心库。



## JSTL五大子库

| Core （核心库） | 标签库的URI：http://java.sun.com/jsp/jstl/core  常用前缀：c  |
| --------------- | ------------------------------------------------------------ |
| I18N（国际化）  | 标签库的URI：http://java.sun.com/jsp/jstl/fmt 常用前缀：fmt  |
| SQL             | 标签库的URI：http://java.sun.com/jsp/jstl/sql  常用前缀：sql |
| XML             | 标签库的URI：http://java.sun.com/jsp/jstl/xml 常用前缀：x    |
| Functions       | 标签库的URI：http://java.sun.com/jsp/jstl/functions  常用前缀：fn |

在Jsp页面中插入

```jsp
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="functions"%>
```

### Core用法

##### forEach 

循环集合里面的对象

```jsp
<c:forEach items="${requestScope.goodstypes }" var="goodstype">
				<tr>
						<td>${goodstype.typeid}</td>
						<td>${goodstype.typename}</td>
						<td>${goodstype.typeinfo}</td>
						<td><a class="layui-btn layui-btn-sm"
							href="dogt?op=toedit&id=${goodstype.typeid}">修改</a>
							<a class="layui-btn layui-btn-sm layui-btn-danger"
							href="dogt?op=dodel&id=${goodstype.typeid}" 
							onclick="return del();">删除</a></td>
					</tr>
				</c:forEach>
```

##### if

单分支判断

```jsp
<c:if test=""></c:if>
```



##### choose、when、otherwise

多分支判断(switch)

```jsp
<c:choose>
			<c:when test=""></c:when>
			<c:otherwise></c:otherwise>
		</c:choose>
```

