# FastJson介绍使用

前后端分离时,controller控制层返回是json数据

加载依赖

```xaml
<dependency>
			<groupId>com.alibaba</groupId>
			<artifactId>fastjson</artifactId>
			<version>1.2.62</version>
		</dependency>
```

SSM框架中需要配置默认@ResponseBody  样式
Spring-MVC配置文件中需要配置

```xml
<!-- MVC注解映射 -->
	<mvc:annotation-driven>
		<mvc:message-converters
			register-defaults="true">
			<!-- 处理响应为text/plain时的body编码 -->
			<bean
				class="org.springframework.http.converter.StringHttpMessageConverter">
				<constructor-arg index="0" value="UTF-8" />
			</bean>
			<!-- 配置Fastjson支持 -->
			<!-- 使用fastjson序列化json数据 -->
			<bean
				class="com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter">
				<property name="supportedMediaTypes">
					<list>
						<value>text/html;charset=UTF-8</value>
						<value>application/json</value>
					</list>
				</property>
				<property name="features">
					<list>
						<!-- 输出key时是否使用双引号 -->
						<value>QuoteFieldNames</value>
						<!-- 是否输出值为null的字段 -->
						<!-- <value>WriteMapNullValue</value> -->
						<!-- 数值字段如果为null,输出为0,而非null -->
						<value>WriteNullNumberAsZero</value>
						<!-- List字段如果为null,输出为[],而非null -->
						<value>WriteNullListAsEmpty</value>
						<!-- 字符类型字段如果为null,输出为"",而非null -->
						<value>WriteNullStringAsEmpty</value>
						<!-- Boolean字段如果为null,输出为false,而非null -->
						<value>WriteNullBooleanAsFalse</value>
						<!-- null String不输出 -->
						<value>WriteNullStringAsEmpty</value>
						<!-- null String也要输出 -->
						<!-- <value>WriteMapNullValue</value> -->

						<!-- Date的日期转换器 -->
						<value>WriteDateUseDateFormat</value>
						<!-- 消除循环依赖 -->
						<value>DisableCircularReferenceDetect</value>
					</list>
				</property>
			</bean>
		</mvc:message-converters>
	</mvc:annotation-driven>
```



## 用法 一:

**当实体类 model类为日期时间类型我们需要给他定义格式**

```java
//对象转成日期字符串 fastjosn 中的注解 不然默认为毫秒数
@JSONField(format = "yyyy-MM-dd")
//页面上接收日期类型 固定日期格式 spring-framework中的
@DateTimeFormat(pattern = "yyyy-MM-dd")
private Date date;
```



## 用法 二:

**当controller 控制层返回json对象**

```java
protected void doListJson(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		GoodsService goodsService = new GoodsServiceImpl();
		List<Goods> goodss = goodsService.getAll();
		String goodssJsonStr = JSON.toJSONString(goodss,SerializerFeature.DisableCircularReferenceDetect);
		out.print(goodssJsonStr);
	}
```



**JSON.toJSONString**(转的参数,SerializerFeature.DisableCircularReferenceDetect)

##### SerializerFeature.DisableCircularReferenceDetect

取消同对象不解析的方式

默认(已有对象会被代替跳过解析)